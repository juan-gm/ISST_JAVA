package es.upm.dit.isst.huesped.model;

public enum Servicios {
 servicioHabitaciones,
 servicioTransporte,
 servicioPersonalizado,
 servicioOcio,
}
