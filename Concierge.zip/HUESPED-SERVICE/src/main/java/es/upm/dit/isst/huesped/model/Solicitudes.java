package es.upm.dit.isst.huesped.model;

import java.io.Serializable;
import es.upm.dit.isst.huesped.model.Servicios;

public class Solicitudes implements Serializable {
	private static final long serialVersionUID = 1L;
	private int status; // status=0 => enviada status=1 => pendiente  status=2 => realizada
	
}
